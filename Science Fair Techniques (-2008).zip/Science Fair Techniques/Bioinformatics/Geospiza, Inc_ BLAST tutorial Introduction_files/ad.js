﻿var w = window;
w.cafepress_ad_url = '';
w.cafepress_adw = 0;
w.cafepress_adh = 0;
w.cafepress_adl = 0;
w.cafepress_adc = 0;
w.cafepress_bid = 0;
w.cafepress_pid = 0;



function cafepress_addval(key, value) {
	if (value) {
		w.cafepress_ad_url += '&' + key + '=' + value;
	}
}

function cafepress_addval_escaped(key, value) {
	w.cafepress_ad_url = w.cafepress_ad_url.replace(/ /, '');
	if (value) {
		w.cafepress_ad_url += '&' + key + '=' + escape(value);
	}
}

function cafepress_addquotes(value) {
  return (value != null) ? '"' + value + '"' : '""';
}

function cafepress_getvals() {
	var cafepress_adspace_vars = w.cafepress_adspace_id.split("-");
	w.cafepress_pid = cafepress_adspace_vars[0];
	w.cafepress_aid = cafepress_adspace_vars[1];
	w.cafepress_bid = cafepress_adspace_vars[2];
	if (cafepress_adspace_vars[3].indexOf("L") > -1) {
		w.cafepress_adl = cafepress_adspace_vars[3].replace("L","");
		w.cafepress_adc = cafepress_adspace_vars[4];
	} else {
		w.cafepress_adw = cafepress_adspace_vars[3];
		w.cafepress_adh = cafepress_adspace_vars[4];
	}
}

w.cafepress_ad_url = 'http://promo.cafepress.com/ad.aspx?dt=' + Math.round(Math.random() * 1000000)/1000000;

cafepress_getvals();
cafepress_addval('pid',w.cafepress_pid);
cafepress_addval('aid',w.cafepress_aid);
cafepress_addval('bid',w.cafepress_bid);
cafepress_addval('adspace',w.cafepress_adspace_id);
cafepress_addval('opt',w.cafepress_optimize_ok);
cafepress_addval('type',w.cafepress_format_type);
cafepress_addval('adw',w.cafepress_adw);
cafepress_addval('adh',w.cafepress_adh);
cafepress_addval('adl',w.cafepress_adl);
cafepress_addval('adc',w.cafepress_adc);
cafepress_addval_escaped('target',w.cafepress_target_path);
cafepress_addval_escaped('tid',w.cafepress_campaign_id);
cafepress_addval_escaped('k',w.cafepress_keyword_set);
//optional
cafepress_addval_escaped('textcolor',w.cafepress_textcolor);
cafepress_addval_escaped('textcolor2',w.cafepress_textcolor2);
cafepress_addval_escaped('bgcolor',w.cafepress_bgcolor);
cafepress_addval_escaped('bgcolor2',w.cafepress_bgcolor2);
cafepress_addval_escaped('linkcolor',w.cafepress_linkcolor);
cafepress_addval_escaped('bordercolor',w.cafepress_bordercolor);
cafepress_addval_escaped('shuffle',w.cafepress_shuffle);
cafepress_addval_escaped('default_term',w.cafepress_default_keyword);

try {
	if (w.top.location != '') {
		cafepress_addval_escaped('ref',w.top.location);
	}
}
catch (e) {
	cafepress_addval_escaped('ref',w.location);
}

if ((w.cafepress_adl > 0) || (w.cafepress_format_type == "js")) {
	cafepress_addval('codesrc','js');
	document.write('<scr' + 'ipt language="javascript" src=' + cafepress_addquotes(w.cafepress_ad_url) + '></scr' + 'ipt>');
} else {
	cafepress_addval('codesrc','iframe');
	document.write('<ifr' + 'ame name="cafepress_adframe"' +
								 ' height=' + cafepress_addquotes(w.cafepress_adh) +
								 ' width=' + cafepress_addquotes(w.cafepress_adw) +
								 ' src=' + cafepress_addquotes(w.cafepress_ad_url) +
								 ' marginheight="0" marginwidth="0" vspace="0" hspace="0" allowtransparency="true" scrolling="no" frameborder="0"></ifr' + 'ame>');
}
